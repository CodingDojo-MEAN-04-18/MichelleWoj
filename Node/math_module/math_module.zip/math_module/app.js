var mathlib = require('./mathlib')();
console.log(mathlib);
mathlib.add(1,2);
mathlib.multiply(1,2);
mathlib.square(2);
mathlib.random(1,10);